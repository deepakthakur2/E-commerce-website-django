Only super user can add update and delete the books, so if you need full access on the project, if you want to a saler than you 
should make first a superuser by simply typing command in terminal 'python manage.y create superuser'
and follow 3 or 4 steps than you will be created superuser and than you should login by our website as saler
and you can update books detail and delete the and add them. but if you are customer user than you can't get access
my superuser is :- deepak
password:-1234


# I've removed virtual environment from my project because that file was too big so my project can't upload on github
so to upload my project i've to remove virtual environment folder from it.
some important modules and libraries you should must download from terminal using pip command:

1) Django-countries,
2) Pillow,
3) razorpay


otherwise code will gave error. please download